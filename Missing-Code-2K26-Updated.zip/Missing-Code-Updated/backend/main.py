from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from questions import QUESTIONS

app = FastAPI(title="Missing Code - Round 1")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

results = []

class Submission(BaseModel):
    participant: str
    language: str
    answers: list[list[int]]
    time_taken: int = 0

@app.get("/questions/{language}")
def get_questions(language: str):
    language = language.lower()
    if language not in {"c", "python", "java"}:
        return {"error": "Choose C, Python or Java"}

    public_questions = []
    for q in QUESTIONS:
        blocks = q["languages"][language]
        public_questions.append({
            "id": q["id"],
            "title": q["title"],
            "blocks": blocks
        })
    return {"language": language, "questions": public_questions}

@app.post("/submit")
def submit(data: Submission):
    language = data.language.lower()
    if language not in {"c", "python", "java"}:
        return {"error": "Invalid language"}

    score = 0
    details = []

    for index, q in enumerate(QUESTIONS):
        submitted = data.answers[index] if index < len(data.answers) else []
        correct = list(range(len(q["languages"][language])))
        is_correct = submitted == correct
        score += int(is_correct)
        details.append({"question": q["id"], "correct": is_correct})

    total = len(QUESTIONS)
    result = {
        "participant": data.participant.strip() or "Anonymous",
        "language": language.upper(),
        "score": score,
        "total": total,
        "percentage": round(score / total * 100, 2),
        "time_taken": data.time_taken
    }
    results.append(result)

    ranked = sorted(results, key=lambda x: (-x["score"], x["time_taken"]))
    rank = next(i for i, r in enumerate(ranked, 1) if r is result)

    return {
        "result": result,
        "rank": rank,
        "details": details,
        "qualified": score >= 7,
        "leaderboard": ranked[:20]
    }

@app.get("/leaderboard")
def leaderboard():
    ranked = sorted(results, key=lambda x: (-x["score"], x["time_taken"]))
    return {"leaderboard": ranked[:20]}

@app.delete("/leaderboard")
def clear_leaderboard():
    results.clear()
    return {"message": "Leaderboard cleared"}
