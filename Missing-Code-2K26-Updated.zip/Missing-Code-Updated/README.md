# Missing Code 2K26 — Updated Round 1

## Structure

There are exactly **10 questions total**.

Every question has the **same programming problem** in all three languages:

1. Even or Odd
2. Largest of Two Numbers
3. Sum of Two Numbers
4. Factorial
5. Prime Number Check
6. Reverse a Number
7. Palindrome Number
8. Fibonacci Series
9. Maximum in Array/List
10. Count Vowels

A participant chooses **one language: C, Python or Java** and receives all 10 questions in that language.

## Run

Open the `Missing-Code-Updated` folder in VS Code.

### Terminal

```bash
cd backend
pip install -r ../requirements.txt
uvicorn main:app --reload
```

Then open `frontend/index.html`.

Recommended: install VS Code **Live Server**, right-click `frontend/index.html` → **Open with Live Server**.

Backend:
`http://127.0.0.1:8000`

Leaderboard API:
`http://127.0.0.1:8000/leaderboard`

## Scoring

- 10 questions
- 1 point per correct sequence
- 10-minute timer
- Score >= 7 → Qualified for Round 2
- Leaderboard sorts by score (high to low), then time (low to high)

## Important

The backend contains the answer sequence and the browser only receives block IDs/code. The current leaderboard is in memory, so restarting FastAPI clears it.

For the real event, use SQLite/PostgreSQL and deploy FastAPI to a server so multiple participants can connect at the same time and results persist.
