const API="http://127.0.0.1:8000";
let language="python",questions=[],current=0,answers=[],currentSequence=[];
let secondsLeft=600,timerInterval=null,startedAt=0;

const $=id=>document.getElementById(id);
document.querySelectorAll(".lang").forEach(btn=>btn.onclick=()=>{
 document.querySelectorAll(".lang").forEach(b=>b.classList.remove("active"));
 btn.classList.add("active"); language=btn.dataset.lang;
});
$("startBtn").onclick=startQuiz;
$("submitBtn").onclick=submitCurrent;
$("clearBtn").onclick=clearSequence;
$("restartBtn").onclick=()=>location.reload();

async function startQuiz(){
 const name=$("participant").value.trim();
 if(!name){alert("Enter participant/team name.");return;}
 try{
  const r=await fetch(`${API}/questions/${language}`),d=await r.json();
  if(d.error)throw Error(d.error);
  questions=d.questions;current=0;answers=[];currentSequence=[];
  secondsLeft=600;startedAt=Date.now();
  $("startScreen").classList.add("hidden");$("quizScreen").classList.remove("hidden");
  startTimer();renderQuestion();
 }catch(e){alert("Backend not connected. Start FastAPI first.");console.error(e);}
}

function startTimer(){
 clearInterval(timerInterval);updateTimer();
 timerInterval=setInterval(()=>{secondsLeft--;updateTimer();if(secondsLeft<=0){clearInterval(timerInterval);finishQuiz();}},1000);
}
function updateTimer(){
 const m=String(Math.floor(secondsLeft/60)).padStart(2,"0");
 const s=String(secondsLeft%60).padStart(2,"0");$("timer").textContent=`${m}:${s}`;
}

function renderQuestion(){
 const q=questions[current];$("progress").textContent=`Question ${current+1} / ${questions.length}`;
 $("scoreLive").textContent=`Answered: ${answers.filter(Boolean).length}`;
 $("questionTitle").textContent=`${q.id} — ${q.title} (${language.toUpperCase()})`;
 currentSequence=[];
 const shuffled=[...q.blocks].sort(()=>Math.random()-.5);
 $("blocks").innerHTML="";$("answer").innerHTML="";
 shuffled.forEach(b=>$("blocks").appendChild(createBlock(b)));
 setupDrop($("blocks"));setupDrop($("answer"));
}
function createBlock(block){
 const d=document.createElement("div");d.className="code-block";d.draggable=true;
 d.dataset.id=block.id;d.textContent=block.code;
 d.ondragstart=e=>e.dataTransfer.setData("text/plain",block.id);
 d.onclick=()=>{const target=d.parentElement.id==="answer"?$("blocks"):$("answer");target.appendChild(d);rebuildSequence();};
 return d;
}
function setupDrop(container){
 container.ondragover=e=>e.preventDefault();
 container.ondrop=e=>{
  e.preventDefault();const id=e.dataTransfer.getData("text/plain");
  const item=[...document.querySelectorAll(".code-block")].find(x=>x.dataset.id===id);
  if(item){const after=getAfter(container,e.clientY);after?container.insertBefore(item,after):container.appendChild(item);rebuildSequence();}
 };
}
function getAfter(container,y){
 return [...container.querySelectorAll(".code-block")].reduce((best,el)=>{
  const box=el.getBoundingClientRect(),offset=y-box.top-box.height/2;
  return offset<0&&offset>best.offset?{offset,el}:best;
 },{offset:-Infinity}).el;
}
function rebuildSequence(){currentSequence=[...document.querySelectorAll("#answer .code-block")].map(x=>Number(x.dataset.id));}
function clearSequence(){[...$("answer").querySelectorAll(".code-block")].forEach(x=>$("blocks").appendChild(x));currentSequence=[];}

function submitCurrent(){
 rebuildSequence();
 if(currentSequence.length!==questions[current].blocks.length){alert("Arrange all blocks first.");return;}
 answers[current]=currentSequence;
 if(current<questions.length-1){current++;renderQuestion();}else finishQuiz();
}

async function finishQuiz(){
 clearInterval(timerInterval);rebuildSequence();
 if(current<questions.length&&!answers[current])answers[current]=currentSequence;
 while(answers.length<questions.length)answers.push([]);
 const timeTaken=Math.floor((Date.now()-startedAt)/1000);
 try{
  const r=await fetch(`${API}/submit`,{method:"POST",headers:{"Content-Type":"application/json"},
   body:JSON.stringify({participant:$("participant").value.trim(),language,answers,time_taken:timeTaken})});
  const d=await r.json();if(d.error)throw Error(d.error);
  $("quizScreen").classList.add("hidden");$("resultScreen").classList.remove("hidden");
  $("resultSummary").innerHTML=`<div class="${d.qualified?"success":"warning"}">
   <h3>${esc(d.result.participant)}</h3>
   <p><b>Language:</b> ${d.result.language}</p><p><b>Score:</b> ${d.result.score}/${d.result.total}</p>
   <p><b>Rank:</b> #${d.rank}</p><p><b>Status:</b> ${d.qualified?"Qualified for Round 2":"Not Qualified"}</p></div>`;
  renderLeaderboard(d.leaderboard);
 }catch(e){alert("Submission failed. Check FastAPI.");console.error(e);}
}
function renderLeaderboard(rows){
 $("leaderboard").innerHTML=`<table><thead><tr><th>Rank</th><th>Participant</th><th>Language</th><th>Score</th><th>Time</th></tr></thead><tbody>${
 rows.map((r,i)=>`<tr><td>#${i+1}</td><td>${esc(r.participant)}</td><td>${r.language}</td><td>${r.score}/${r.total}</td><td>${fmt(r.time_taken)}</td></tr>`).join("")
 }</tbody></table>`;
}
function fmt(s){return `${Math.floor(s/60)}m ${s%60}s`;}
function esc(v){return String(v).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}
